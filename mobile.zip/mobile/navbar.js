$(document).ready(function(){

    $("#div1").load("navbar.html");

});